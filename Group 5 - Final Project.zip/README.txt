Instant Messenger
Matthew Kramer, Michael Music, and Sterling Price

To run the application, first start the server:

	python server.py

Then create clients in other terminals:

	python client.py

For further instructions, see the 'Execution' section of the included report.